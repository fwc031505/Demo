package jdbccreate;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * 执行线程池中的单线程任务：
 * 对数据库数据执行简单的增删改查
 */
public class SingleThread implements Runnable {
    /**
     * sql语句字段的值
     */
    private Object[] values;

    /**
     * 定义sql语句字段的值
     */
    public SingleThread(Object... values) {
        this.values = values;
    }

    @Override
    public void run() {
        Connection conn = null;
        PreparedStatement statement = null;
        String sql;
        try {
            //建立一个连接
            conn = WSConnectionPoolManage.getConnection();
            //推荐用占位符?，避免引发SQL注入的问题，即尽量使用prepareStatement()

            //执行一个插入语句
            sql = "insert into hero values (?,?,?)";
            statement = conn.prepareStatement(sql);
            for (int i = 1; i <= values.length; i++) {
                statement.setObject(i, values[i - 1]);
            }
            //执行插入并获得返回的结果集
            statement.executeUpdate();
            //关闭PreparedStatement资源
            // 也可以使用try (resource)确保及时关闭，resource要求实现java.lang.AutoCloseable接口
            statement.close();
            //释放一个连接，其实是将连接置为空闲连接
            WSConnectionPoolManage.releaseConnection(conn);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

