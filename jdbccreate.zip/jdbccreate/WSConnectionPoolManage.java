package jdbccreate;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


import java.sql.Connection;

/**
 * 测试类
 * 连接池管理类
 * 含有唯一的连接池类
 * 只负责连接的获取和释放
 */
public class WSConnectionPoolManage {
    /**
     * 唯一的连接池类（单例模式，数据共享，线程不安全）
     */
    private static WSConnectionPool connectionPool=new WSConnectionPool();

    /**
     * 获取数据库连接的方法
     * 上锁，多线程情况下确保连接池唯一
     */
    public static synchronized Connection getConnection() {
        return connectionPool.getConnection();
    }

    /**
     * 释放数据库连接的方法
     */
    public static synchronized void releaseConnection(Connection connection) {
        connectionPool.releaseConnection(connection);
    }
    /**
     * 主方法
     */
    public static void main(String[] args) {
        // 创建一个固定大小的线程池:
        ExecutorService es = Executors.newFixedThreadPool(3);
        for (int i = 0; i < 3; i++) {
            //连接后自动调用run()方法
            es.submit(new SingleThread(1,"fang"+i,i+20));
        }
        es.shutdown();
    }
}

