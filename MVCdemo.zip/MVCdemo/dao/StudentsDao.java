package MVCdemo.dao;


import MVCdemo.entity.Students;

import java.util.List;

/**
 * Dao接口
 * 执行sql语句操作数据库
 *
 * @author admin
 */
public interface StudentsDao {
    /**
     * 增
     *
     * @param student 一条学生数据
     */
    public int insert(Students student);

    /**
     * 改
     *
     * @param student 一条学生数据
     */
    public int update(Students student);

    /**
     * 删
     *
     * @param id 主键
     */
    public int delete(int id);

    /**
     * 查
     *
     * @param id 主键
     */
    public Students select(int id);

    /**
     * 查全部
     */
    public List<Students> selectAll();

    public StudentsDao getstudentsDao();

}