package MVCdemo.dao;

import MVCdemo.advanced.RowMapperImpl;
import MVCdemo.entity.Students;
import MVCdemo.utils.DaoUtils;

import java.util.List;


/**
 * Dao接口实现类
 * 实现具体sql语句
 * @author admin
 */
public class StudentsDaoImpl implements StudentsDao {

    private DaoUtils<Students>daoUtils = new DaoUtils();
    /**
     * @return StudentsDaoImpl对象
     */
    public StudentsDao getstudentsDao() {
        return new StudentsDaoImpl();
    }

    @Override
    public int insert(Students student) {
        String sql = "insert into students(name,gender,grade,score) values(?,?,?,?);";
        Object[] args = {student.getName(), student.getGender(), student.getGrade(), student.getScore()};
        return daoUtils.commonsUpdate(sql, args);
    }

    @Override
    public int update(Students student) {
        String sql = "update students set name=?,gender=?,grade=?,score=? where id = ?";
        Object[] args = {student.getName(), student.getGender(), student.getGrade(), student.getScore(), student.getId()};
        return daoUtils.commonsUpdate(sql, args);
    }
    @Override
    public Students select(int id) {
        String sql = "select * from students where id = ?";
        List<Students> list = daoUtils.commonSelect(sql, new RowMapperImpl(), id);
        if (!list.isEmpty()) {
            return list.get(0);
        }
        return null;

    }
    @Override
    public int delete(int id) {
        String sql = "delete from students where id = ?";
        return daoUtils.commonsUpdate(sql, id);
    }
    @Override
    public List<Students> selectAll() {
        String sql = "select * from students";
        List<Students> list = daoUtils.commonSelect(sql, new RowMapperImpl());
        //将集合中每个object元素强转为Students 再存放在list<Students>
        return list;
    }


}
