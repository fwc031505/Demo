package MVCdemo.utils;


import MVCdemo.advanced.RowMapper;
import MVCdemo.entity.Students;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * 数据库的具体操作（增删改查）
 *
 * @author admin
 */
public class DaoUtils<T> {


    public DaoUtils() {
    }

    public static final Logger LOGGER = LoggerFactory.getLogger("DaoUtils.class");
    Connection connection = null;
    PreparedStatement preparedStatement = null;

    /**
     * 公共处理增删改的方法
     * sql 执行的sql语句
     * args 参数列表
     * return 受影响的行数
     */
    public int commonsUpdate(String sql, Object... args) {
        connection = DbUtils.getConnection();
        try {
            preparedStatement = connection.prepareStatement(sql);
            for (int i = 0; i < args.length; i++) {
                preparedStatement.setObject(i + 1, args[i]);
            }
            int result = preparedStatement.executeUpdate();
            return result;
        } catch (SQLException e) {
            LOGGER.error(e.toString());
        } finally {
            DbUtils.close(preparedStatement, connection);
        }
        return 0;
    }

    /**
     * 公共的查询方法（可查询任意一张表，可查询单个对象，也可查询整张表）
     * sql 执行的sql语句
     * args 参数列表
     * return 集合
     */
    public List<T> commonSelect(String sql, RowMapper<T> rowMapper, Object... args) {

        ResultSet resultSet = null;
        List<T> list = new ArrayList<>();
        connection = DbUtils.getConnection();
        try {
            preparedStatement = connection.prepareStatement(sql);
            for (int i = 0; i < args.length; i++) {
                preparedStatement.setObject(i + 1, args[i]);
            }
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                T t = rowMapper.getRow(resultSet);
                list.add(t);
            }
            //将集合中每个object元素强转为Students,再存放在list<Students>
            return list;

        } catch (SQLException e) {
            LOGGER.error(e.toString());
        } finally {
            DbUtils.close(resultSet, preparedStatement, connection);
        }
        return null;
    }

}
