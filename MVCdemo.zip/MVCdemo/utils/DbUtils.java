package MVCdemo.utils;

import com.alibaba.druid.pool.DruidDataSourceFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

/**
 * 连接数据库工具类
 * @author admin
 */
public class DbUtils {
    public static final Logger LOGGER = LoggerFactory.getLogger("DbUtils.class");
    private static DataSource ds;
    static {
        try {
            //1.数据源配置
            Properties pro = new Properties();
            //2.通过当前类的class对象获取资源文件
            InputStream is = DbUtils.class.getResourceAsStream("druid.properties");
            pro.load(is);
            //3.获取DataSource
            ds = DruidDataSourceFactory.createDataSource(pro);
        } catch (IOException e) {
            LOGGER.error(e.toString());
        } catch (Exception e) {
            LOGGER.error(e.toString());
        }
    }

    /**
     * 获取连接
     */
    public static Connection getConnection()  {
        try {
            return ds.getConnection();
        } catch (SQLException e) {
            LOGGER.error(e.toString());
        }
        return null;
    }

    /**
     * 释放资源(增删改)
     */
    public static void close(PreparedStatement stmt, Connection conn) {
        close(null, stmt, conn);
    }

    /**
     * 释放资源(查)
     */
    public static void close(ResultSet rs, PreparedStatement stmt, Connection conn) {

        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                LOGGER.error(e.toString());
            }
        }
        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException e) {
                LOGGER.error(e.toString());
            }
        }

        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                LOGGER.error(e.toString());
            }
        }
    }

    /**
     * 获取连接池
     * @return DataSource
     */
    public static DataSource getDataSource() {
        return ds;
    }



}
