package MVCdemo.advanced;


import java.sql.ResultSet;

/**
 * 封装一行数据
 * 对数据进行泛型，以便于适用于其他相似的数据操作
 * @author admin
 */
public interface RowMapper<T> {
    /**
     *
     * @param resultSet 数据库一行的数据
     * @return 操作对象
     */
    public T getRow(ResultSet resultSet);
}
