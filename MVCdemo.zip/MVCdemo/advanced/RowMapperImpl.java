package MVCdemo.advanced;


import MVCdemo.entity.Students;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @author admin
 */
public class RowMapperImpl implements  RowMapper<Students> {
  public static final Logger LOGGER = LoggerFactory.getLogger("RowMapperImpl.class");

  public RowMapperImpl() {
  }

  @Override
  public Students getRow(ResultSet resultSet) {
    try {
      int id = resultSet.getInt("id");
      String name = resultSet.getString("name");
      int gender = resultSet.getInt("gender");
      int grade = resultSet.getInt("grade");
      int score = resultSet.getInt("score");
      Students students = new Students(id, name, gender, grade, score);
      return students;
    } catch (SQLException e) {
LOGGER.error(e.toString());
    }
    return null;


  }
}