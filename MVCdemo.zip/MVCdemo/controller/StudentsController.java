package MVCdemo.controller;

import MVCdemo.dao.StudentsDao;
import MVCdemo.dao.StudentsDaoImpl;
import MVCdemo.entity.Students;
import MVCdemo.service.StudentsService;
import MVCdemo.service.StudentsServiceImpl;
import java.util.Scanner;

/**
 * 表示层，收集用户输入数据，展示数据或操作结果
 *
 * @author admin
 */
public class StudentsController {
    static StudentsService studentsService = StudentsServiceImpl.getStudentsServiceImpl();
    static StudentsDao studentsDao = new StudentsDaoImpl().getstudentsDao();

    /**
     * @return 输入的信息，如用户或功能的选择，修改的信息等
     */
    public static int select() {
        Scanner scanner = new Scanner(System.in);
        int input = scanner.nextInt();
        return input;
    }

    /**
     * 输入要插入的学生信息（id自增，不需要写）
     * @return 插入的数据的数量
     */
    public static int insertStudent() {
        Scanner scanner = new Scanner(System.in);
        Students students = new Students();
        System.out.print("输入姓名:");
        students.setName(scanner.next());
        System.out.print("输入性别:");
        students.setGender(select());
        System.out.print("输入等级:");
        students.setGrade(select());
        System.out.print("输入成绩:");
        students.setScore(select());
        //判断插入的数据的合法性
        boolean bool = studentsService.isInsertOrUpdate(students);
        if (bool) {
            int sum = studentsDao.insert(students);
            return sum;
        }
        return 0;
    }

    /**
     * 根据id查询学生
     * @return 查询的学生信息
     */
    public static Students selectId() {
        int id = StudentsController.select();
        Students student = studentsDao.select(id);
        return student;
    }

    /**
     * 根据id删除学生
     * @return 删除的学生数量
     */
    public static int delectId() {
        int id = StudentsController.select();
        int sum = studentsDao.delete(id);
        return sum;
    }

    /**
     * 输入要更新的学生信息（根据id）
     * @return 更新的学生的数量
     */
    public static int updateStudent() {
        Students students = new Students();
        Scanner scanner = new Scanner(System.in);

        System.out.print("输入id:");
        students.setId(select());
        System.out.print("输入姓名:");
        students.setName(scanner.next());
        System.out.print("输入性别:");
        students.setGender(select());
        System.out.print("输入等级:");
        students.setGrade(select());
        System.out.print("输入成绩:");
        students.setScore(select());
        //判断更新的数据的合法性
        boolean bool = studentsService.isInsertOrUpdate(students);
        if (bool) {
            int sum = studentsDao.update(students);
            return sum;
        }
        return 0;
    }

}
