package MVCdemo.entity;


/**
 * 实体类
 *
 * @author admin
 */
public class Students {
    private int id;
    private String name;
    private int gender;
    private int grade;
    private int score;

    public Students() {
    }

    public Students(int id, String name, int gender, int grade, int score) {
        this.id = id;
        this.name = name;
        this.gender = gender;
        this.grade = grade;
        this.score = score;
    }
    @Override
    public String toString() {
        return "学生信息: " +
                "id=" + id +
                ", name=" + name +
                ", gender=" + grade +
                ", grade=" + grade +
                ", score=" + score
                ;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public int getGrade() {
        return grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    public int getGender() {
        return gender;
    }

    public void setGender(int gender) {
        this.gender = gender;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
