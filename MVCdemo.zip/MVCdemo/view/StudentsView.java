package MVCdemo.view;

import MVCdemo.controller.StudentsController;
import MVCdemo.service.StudentsService;
import MVCdemo.service.StudentsServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * 视图，提供输入界面，返回操作后的结果
 *
 * @author admin
 */
public class StudentsView {
    public static final Logger LOGGER = LoggerFactory.getLogger("StudentsView.class");
    static public Map<Integer, String> user = new HashMap<>();
    static public Map<Integer, String> function = new HashMap<>();
    StudentsService studentsService = StudentsServiceImpl.getStudentsServiceImpl();

    //静态代码块，初始化user和function
    static {
        user.put(1, "学生");
        user.put(2, "班主任");
        user.put(3, "管理员");

        function.put(1, "增");
        function.put(2, "删");
        function.put(3, "改");
        function.put(4, "查");
        function.put(5, "查询全部");
    }

    public StudentsView() {
    }

    public void showView() {
        System.out.print("进入学生管理系统\n选择登录用户：");
        for (Map.Entry<Integer, String> entry : user.entrySet()) {
            System.out.print(entry.getKey() + "--" + entry.getValue() + "\t");
        }
        System.out.println();
        int key;

        LOGGER.info("进入循环，选择用户，正确选择后退出循环");
        for (; ; ) {
            //退出循环的标志，1则退出
            int exitFlag = 1;
            /*用户选择
             * 普通用户：查询一个学生
             * 班主任：查询整张表的学生
             * 管理员：5个功能
             * */
            LOGGER.info("进入switch分支");
            switch (key = StudentsController.select()) {
                case 1:
                case 2:
                    break;
                case 3:
                    System.out.print("请输入管理密码：");
                    if (!studentsService.isPasswordRight()) {
                        studentsService.quit();
                    }
                    break;
                default:
                    exitFlag = 0;
                    System.out.println("无效用户，请重新输入");
                    break;
            }
            if (exitFlag == 1) {
                LOGGER.info("退出循环");
                break;
            }
        }

        LOGGER.info("进入循环，可调用isExit()选择是否退出");
        for (; ; ) {
            int exitFlag = 1;
            if (key == 1) {
                for (; ; ) {
                    StudentsFunctionExecute.functionSelect(4);
                    studentsService.isQuit();
                }
            } else if (key == 2) {
                for (; ; ) {
                    StudentsFunctionExecute.functionSelect(5);
                    studentsService.isQuit();
                }
            } else { LOGGER.info("进入循环，选择管理员功能，正确选择后退出循环");
                for (; ; ) {
                    System.out.print("选择功能：");
                    for (Map.Entry<Integer, String> entry : function.entrySet()) {
                        System.out.print(entry.getKey() + "--" + entry.getValue() + "\t");
                    }
                    System.out.println();
                    LOGGER.info("进入switch分支");
                    switch (key = StudentsController.select()) {
                        case 1:
                            StudentsFunctionExecute.functionSelect(1);
                            break;
                        case 2:
                            StudentsFunctionExecute.functionSelect(2);
                            break;
                        case 3:
                            StudentsFunctionExecute.functionSelect(3);
                            break;
                        case 4:
                            StudentsFunctionExecute.functionSelect(4);
                            break;
                        case 5:
                            StudentsFunctionExecute.functionSelect(5);
                            break;
                        default:
                            exitFlag = 0;
                            System.out.println("无效功能，请重新输入");
                            break;
                    }

                    if (exitFlag == 1) {LOGGER.info("退出循环");
                        break;
                    }
                }
                studentsService.isQuit();
            }
        }
    }
}

