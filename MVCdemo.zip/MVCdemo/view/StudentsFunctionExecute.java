package MVCdemo.view;


import MVCdemo.controller.StudentsController;
import MVCdemo.entity.Students;
import MVCdemo.service.StudentsService;
import MVCdemo.service.StudentsServiceImpl;

/**
 * 执行选择的功能
 *
 * @author admin
 */
public class StudentsFunctionExecute {
    static StudentsService studentsService = StudentsServiceImpl.getStudentsServiceImpl();

    /**
     * 功能执行
     *
     * @param select 选择的功能
     */
    public static void functionSelect(int select) {
        switch (select) {
            //增
            case 1:
                System.out.println("请输入要增加的学生信息");
                int sc = StudentsController.insertStudent();
                if (sc == 0) {
                    System.out.println("增加失败");
                } else {
                    System.out.println("增加了" + sc + "位学生");

                }
                break;
            //删
            case 2:
                System.out.println("请输入id,删除该学生");
                int sc2 = StudentsController.delectId();
                if (sc2 == 0) {
                    System.out.println("id不存在！");
                } else {
                    System.out.println("删除了" + sc2 + "位学生");
                }
                break;
            //改
            case 3:
                System.out.println("请输入要修改的学生信息");
                int us = StudentsController.updateStudent();
                if (us == 0) {
                    System.out.println("id不存在或信息错误！");
                } else {
                    System.out.println("修改了" + us + "位学生");
                }
                break;
            //查
            case 4:
                System.out.println("请输入id,查询该学生");
                Students student = StudentsController.selectId();
                if (student == null) {
                    System.out.println("id不存在！");
                } else {
                    System.out.println(student);
                }
                break;
            //查全部数据
            case 5:
                System.out.println("查询表中所有学生");
                studentsService.studentsDao().forEach(System.out::println);
                break;
            default:
                break;

        }

    }
}
