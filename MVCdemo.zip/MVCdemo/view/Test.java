package MVCdemo.view;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 测试类
 * @author admin
 */

public class Test {
    public static final Logger LOGGER = LoggerFactory.getLogger("Test.class");

    public static void main(String[] args) {

        StudentsView studentsView = new StudentsView();
        studentsView.showView();
    }
}
