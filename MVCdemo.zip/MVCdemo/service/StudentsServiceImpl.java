package MVCdemo.service;


import MVCdemo.controller.StudentsController;
import MVCdemo.dao.StudentsDao;
import MVCdemo.dao.StudentsDaoImpl;
import MVCdemo.entity.Students;
import MVCdemo.utils.DbUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;

/**
 * Service实现类
 *
 * @author admin
 */
public class StudentsServiceImpl implements StudentsService {
    public static final Logger LOGGER = LoggerFactory.getLogger("StudentsServiceImpl.class");
    /**
     * 下面for循环的条件限制需要
     */
    public static final int FLAG = 3;
    /**
     * 名字的长度限制
     */
    public static final int NAME_LENGTH = 50;
    /**
     * 等级的最大值
     */
    public static final int GRADE_MAX = 5;
    /**
     * 最高成绩
     */
    public static final int SCORE_MAX = 100;
    /**
     * 密码(常量)
     */
    private static final String password = "123456";
    StudentsDao studentsDao = new StudentsDaoImpl().getstudentsDao();

    public static StudentsServiceImpl getStudentsServiceImpl() {
        return new StudentsServiceImpl();
    }

    @Override
    public List<Students> studentsDao() {
        List<Students> list = studentsDao.selectAll();
        return list;
    }

    @Override
    public boolean isPasswordRight() {
        LOGGER.info("进入循环，输入密码正确或超过3次退出");
        for (int i = 0; i < FLAG; i++) {
            if (!password.equals(StudentsController.select())) {
                return true;
            }
            System.out.print("密码输入错误，还有" + (FLAG-1- i) + "次机会)");
        }
        return false;
    }

    @Override
    public void quit() {
        System.out.print("系统即将退出...");
        System.exit(0);
    }

    @Override
    public void isQuit() {
        System.out.print("是否退出");
        if (StudentsController.select() == 1) {
            quit();
        }
    }
    @Override
    public boolean isInsertOrUpdate(Students students) {
        LOGGER.info("检查数据合法性");
        if (students.getName().length() <= NAME_LENGTH) {
            if (students.getGender() == 0 || students.getGender() == 1) {
                if (students.getGrade() > 0 && students.getGrade() < GRADE_MAX) {
                    if (students.getScore() >= 0 && students.getScore() <= SCORE_MAX) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

}

