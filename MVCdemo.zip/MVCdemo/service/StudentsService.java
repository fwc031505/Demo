package MVCdemo.service;


import MVCdemo.dao.StudentsDao;
import MVCdemo.entity.Students;

import java.util.List;

/**
 * 系统的登录和退出，以及检查数据库操作的合法性
 * @author admin
 */
public interface StudentsService {

    /**
     * 判断密码正误
     * @return 判断结果
     */
    public boolean isPasswordRight();

    /**
     * 退出系统
     */
    public  void quit();

    /**
     *合法性判断
     * @param students 要插入或更新的学生
     * @return 判断结果
     */
    public boolean isInsertOrUpdate(Students students);

    /**
     * 用来调用dao层的查询功能
     * @return list集合，存储了整张表
     */
    public List<Students> studentsDao();

    /**
     * 是否退出系统
     */
    public void isQuit();
}
